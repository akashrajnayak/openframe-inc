import CoreGraphics

public struct SpringConfig {
    public var stiffness: CGFloat = 180
    public var damping: CGFloat = 16
    public var mass: CGFloat = 1
}

public func sampleSpringCurve(_ config: SpringConfig, steps: Int = 60) -> [CGFloat] {
    let dt: CGFloat = 1.0 / 60.0
    var pos: CGFloat = 0
    var vel: CGFloat = 0
    var out: [CGFloat] = []
    for _ in 0..<steps {
        let force = -config.stiffness * (pos - 1.0)
        let damper = -config.damping * vel
        vel += ((force + damper) / config.mass) * dt
        pos += vel * dt
        out.append(pos)
    }
    return out
}
