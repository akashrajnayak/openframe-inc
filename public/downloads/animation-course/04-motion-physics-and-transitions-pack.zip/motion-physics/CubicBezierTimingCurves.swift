import UIKit

public enum MotionCurves {
    public static let snappyEaseOut = UICubicTimingParameters(controlPoint1: CGPoint(x: 0.16, y: 1), controlPoint2: CGPoint(x: 0.3, y: 1))
    public static let elasticSpring = UISpringTimingParameters(mass: 1.0, stiffness: 220, damping: 18, initialVelocity: .zero)
}
