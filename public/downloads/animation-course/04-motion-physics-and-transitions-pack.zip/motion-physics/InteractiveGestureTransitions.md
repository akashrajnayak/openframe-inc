# Interactive Gesture & Compositor Motion Guide
- Animate transform and opacity only for 60fps performance.
- Respect prefers-reduced-motion accessibility settings.
- Use damped springs for drag release velocity preservation.
