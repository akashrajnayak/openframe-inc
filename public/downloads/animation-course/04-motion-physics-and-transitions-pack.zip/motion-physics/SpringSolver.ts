export interface SpringConfig { stiffness: number; damping: number; mass: number; }
export function sampleSpringCurve(config: SpringConfig, steps = 60): number[] {
  const dt = 1 / 60;
  let pos = 0, vel = 0;
  const out: number[] = [];
  for (let i = 0; i < steps; i++) {
    const accel = (-config.stiffness * (pos - 1) - config.damping * vel) / config.mass;
    vel += accel * dt;
    pos += vel * dt;
    out.push(pos);
  }
  return out;
}
