# Swift UI Animation Components, Graphs & Charts Masterclass
Repository Source: https://github.com/Ramotion/swift-ui-animation-components-and-libraries.git
Published on OpenFrame Education

## Course Modules
Module 1: Motion Physics, CoreAnimation & SwiftUI Spring Curves
Module 2: Carousels & Feeds (Circular Carousel, CardSlider, Gliding Collection, Garland View)
Module 3: Expandable Cards & Material Surfaces (Folding Cell, Expanding Collection, Elongation Preview, Preview Transition)
Module 4: Navigation & Adaptive Controls (Animated Tab Bar, Adaptive Tab Bar, Navigation Toolbar, Navigation Stack)
Module 5: Interactive Micro-Controls (Circle Menu, Paper Switch, Paper Onboarding, Reel Search, Fluid Slider)
Module 6: Animated Graphs & Data Visualization (Line, Area, Bar, Stacked Bar, Donut/Pie, Radial Rings, Radar, Scatter, Candlestick, Heatmap, Funnel, Treemap, Oscilloscope)
