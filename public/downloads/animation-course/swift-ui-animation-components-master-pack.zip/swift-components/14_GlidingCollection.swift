import GlidingCollection

final class CourseGlidingVC: UIViewController {
    @IBOutlet weak var glidingView: GlidingCollection!
}
