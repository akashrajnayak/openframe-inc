import GarlandView

final class CourseGarlandVC: GarlandViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        GarlandConfig.shared.animationDuration = 0.45
    }
}
