import AdaptiveController

func makeAdaptiveStates(usageCount: Int) -> AdaptiveButtonsStateManager {
    let states: [AdaptiveState] = [NoviceState(), FamiliarState(), ExpertState()]
    return AdaptiveButtonsStateManager(states: states, currentCount: usageCount)
}
