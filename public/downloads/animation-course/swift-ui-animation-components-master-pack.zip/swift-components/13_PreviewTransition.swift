import PreviewTransition

final class CoursePreviewGalleryVC: PTTableViewController {
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        pushViewController(UIViewController())
    }
}
