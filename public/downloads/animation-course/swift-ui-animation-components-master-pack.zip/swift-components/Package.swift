// swift-tools-version:5.5
import PackageDescription

let package = Package(
    name: "OpenFrameSwiftUIAnimationCourse",
    platforms: [.iOS(.v13)],
    dependencies: [
        .package(url: "https://github.com/Ramotion/circular-carousel.git", from: "1.0.0"),
        .package(url: "https://github.com/Ramotion/folding-cell.git", from: "5.0.0"),
        .package(url: "https://github.com/Ramotion/animated-tab-bar.git", from: "5.2.0"),
        .package(url: "https://github.com/Ramotion/paper-onboarding.git", from: "6.1.0"),
        .package(url: "https://github.com/Ramotion/cardslider.git", from: "1.0.0"),
        .package(url: "https://github.com/Ramotion/expanding-collection.git", from: "4.0.0"),
        .package(url: "https://github.com/Ramotion/circle-menu.git", from: "4.1.0"),
        .package(url: "https://github.com/Ramotion/paper-switch.git", from: "4.0.0"),
        .package(url: "https://github.com/Ramotion/fluid-slider.git", from: "1.1.0"),
    ],
    targets: [
        .target(name: "OpenFrameSwiftUIAnimationCourse", dependencies: [])
    ]
)
