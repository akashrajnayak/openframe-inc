import UIKit
import CircularCarousel

final class CircularCarouselDemoVC: UIViewController, CircularCarouselDataSource, CircularCarouselDelegate {
    @IBOutlet weak var carouselView: CircularCarousel!
    func numberOfItems(inCarousel carousel: CircularCarousel) -> Int { 6 }
    func carousel(_ carousel: CircularCarousel, viewForItemAt indexPath: IndexPath, reuseView view: UIView?) -> UIView {
        let card = view ?? UIView(frame: CGRect(x: 0, y: 0, width: 220, height: 280))
        card.layer.cornerRadius = 18
        return card
    }
}
