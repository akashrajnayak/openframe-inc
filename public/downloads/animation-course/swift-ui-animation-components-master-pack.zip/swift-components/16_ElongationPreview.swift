import ElongationPreview

final class CourseElongationVC: ElongationViewController {
    override func openDetailView(for indexPath: IndexPath) {
        expand(viewController: ElongationDetailViewController())
    }
}
