import CircleMenu

func createCircleMenu(in view: UIView, delegate: CircleMenuDelegate) -> CircleMenu {
    let btn = CircleMenu(frame: CGRect(x: 160, y: 300, width: 56, height: 56), normalIcon: "menu", selectedIcon: "close", buttonsCount: 5, duration: 0.45, distance: 120)
    btn.delegate = delegate
    view.addSubview(btn)
    return btn
}
