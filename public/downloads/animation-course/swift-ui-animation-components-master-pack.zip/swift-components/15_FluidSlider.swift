import fluid_slider

func makeFluidSlider() -> Slider {
    let slider = Slider()
    slider.attributedTextForFraction = { f in NSAttributedString(string: "\(Int(f * 100))%") }
    return slider
}
