import expanding_collection

final class CourseExpandingVC: ExpandingViewController {
    override func viewDidLoad() {
        itemSize = CGSize(width: 256, height: 335)
        super.viewDidLoad()
    }
}
