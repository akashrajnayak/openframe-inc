import UIKit
import FoldingCell

final class CourseFoldingCell: FoldingCell {
    override func awakeFromNib() {
        foregroundView.layer.cornerRadius = 12
        foregroundView.layer.masksToBounds = true
        super.awakeFromNib()
    }
    override func animationDuration(_ itemIndex: NSInteger, type: FoldingCell.AnimationType) -> TimeInterval {
        [0.26, 0.2, 0.2][itemIndex]
    }
}
