import UIKit
// NavigationToolbar slide-modeled navigation controller wrapper
final class NavigationToolbarDemoVC: UIViewController {
    var activeIndex: Int = 0
    func selectTab(_ index: Int) { activeIndex = index }
}
