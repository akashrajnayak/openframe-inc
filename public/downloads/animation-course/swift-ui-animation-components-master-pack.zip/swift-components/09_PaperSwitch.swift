import RAMPaperSwitch

func configurePaperSwitch(_ paperSwitch: RAMPaperSwitch) {
    paperSwitch.duration = 0.45
    paperSwitch.animationDidStartClosure = { isOn in print("Radial paint:", isOn) }
}
