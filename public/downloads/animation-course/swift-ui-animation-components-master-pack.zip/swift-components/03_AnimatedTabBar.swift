import RAMAnimatedTabBarController

func makeAnimatedTabs() -> RAMAnimatedTabBarController {
    let controller = RAMAnimatedTabBarController()
    let home = RAMAnimatedTabBarItem(title: "Home", image: UIImage(systemName: "house"), tag: 0)
    home.animation = RAMBounceAnimation()
    let charts = RAMAnimatedTabBarItem(title: "Charts", image: UIImage(systemName: "chart.bar"), tag: 1)
    charts.animation = RAMRotationAnimation()
    controller.viewControllers = [UIViewController(), UIViewController()]
    return controller
}
