import RAMReel

func makeReelSearch(in bounds: CGRect) -> RAMReel<SimplePrefixQueryDataSource> {
    let ds = SimplePrefixQueryDataSource(["Line Chart", "Radar Plot", "Candlestick", "Heatmap", "Folding Cell"])
    return RAMReel(frame: bounds, dataSource: ds, placeholder: "Search...") { print($0) }
}
