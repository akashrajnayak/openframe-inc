import paper_onboarding

final class CourseOnboardingVC: UIViewController, PaperOnboardingDataSource {
    func onboardingItemsCount() -> Int { 3 }
    func onboardingItem(at index: Int) -> OnboardingItemInfo {
        OnboardingItemInfo(informationImage: UIImage(), title: "Step \(index+1)", description: "Material wipe", pageIcon: UIImage(), color: .systemIndigo, titleColor: .white, descriptionColor: .white, titleFont: .boldSystemFont(ofSize: 22), descriptionFont: .systemFont(ofSize: 15))
    }
}
