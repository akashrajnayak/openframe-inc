import Navigation_stack

final class CourseNavigationStack: NavigationStack {
    func revealStackOverview() { showControllers() }
}
