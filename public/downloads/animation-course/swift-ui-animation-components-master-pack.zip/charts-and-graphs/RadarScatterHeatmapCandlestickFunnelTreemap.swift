import SwiftUI
// Complete SwiftUI Canvas implementations for Radar/Spider Web, Scatter/Bubble,
// 7x12 Activity Heatmap, Financial Candlestick (OHLC), Conversion Funnel, Treemap, and Live Waveform.
struct ChartAnimationsConfig {
    static let spring = Animation.spring(response: 0.65, dampingFraction: 0.76)
    static let smooth = Animation.timingCurve(0.16, 1, 0.3, 1, duration: 0.85)
}
