import SwiftUI
import Charts

struct SeriesPoint: Identifiable { let id = UUID(); let x: String; let y: Double; let series: String }

struct AnimatedLineAreaChart: View {
    @State private var trim: CGFloat = 0
    let points: [SeriesPoint]
    var body: some View {
        Chart(points) { pt in
            AreaMark(x: .value("X", pt.x), y: .value("Y", pt.y * trim)).foregroundStyle(by: .value("Series", pt.series)).interpolationMethod(.catmullRom)
            LineMark(x: .value("X", pt.x), y: .value("Y", pt.y * trim)).foregroundStyle(by: .value("Series", pt.series)).interpolationMethod(.catmullRom)
        }.onAppear { withAnimation(.easeOut(duration: 0.9)) { trim = 1 } }
    }
}
