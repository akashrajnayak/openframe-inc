import SwiftUI
import Charts

struct BarDatum: Identifiable { let id = UUID(); let label: String; let value: Double; let group: String }

struct AnimatedBarChart: View {
    @State private var progress: CGFloat = 0
    let items: [BarDatum]
    var body: some View {
        Chart(items) { item in
            BarMark(x: .value("Category", item.label), y: .value("Value", item.value * progress)).foregroundStyle(by: .value("Group", item.group)).cornerRadius(6)
        }.onAppear { withAnimation(.spring(response: 0.7, dampingFraction: 0.72)) { progress = 1 } }
    }
}
