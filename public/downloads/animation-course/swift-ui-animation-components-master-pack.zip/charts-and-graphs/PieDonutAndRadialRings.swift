import SwiftUI
import Charts

struct SliceDatum: Identifiable { let id = UUID(); let name: String; let value: Double }

struct AnimatedDonutChart: View {
    @State private var sweep: Double = 0
    let slices: [SliceDatum]
    var body: some View {
        Chart(slices) { slice in
            SectorMark(angle: .value("Share", slice.value * sweep), innerRadius: .ratio(0.58), angularInset: 2).foregroundStyle(by: .value("Name", slice.name))
        }.onAppear { withAnimation(.easeOut(duration: 0.85)) { sweep = 1 } }
    }
}
