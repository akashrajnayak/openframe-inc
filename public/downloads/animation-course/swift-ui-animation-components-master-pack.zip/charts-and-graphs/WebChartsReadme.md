# Animated Graphs & Charts Reference (12 Chart Types)
Included in the OpenFrame Animation Studio & downloadable ZIP pack:
1. Multi-Series Smooth Line Chart
2. Stacked Gradient Area Chart
3. Grouped & Stacked Bar Chart
4. Interactive Donut & Pie Chart
5. Concentric Radial Progress Rings
6. Multi-Axis Radar / Spider Chart
7. Physics Scatter & Bubble Plot
8. Financial Candlestick (OHLC) + Moving Average
9. 7x12 Activity Heatmap Matrix
10. Conversion Funnel Pipeline
11. Proportional Treemap Blocks
12. Live 60fps Oscilloscope Waveform
